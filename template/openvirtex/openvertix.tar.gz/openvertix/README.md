OpenVirteX
==========


OVX is a network hypervisor that can create multiple virtual and programmable networks on top of a single physical infrastructure. Each tenant can use the full addressing space, specify his own topology, and deploy the network OS of his choice. Networks can be reconfigured at run-time, and OVX can automatically recover from physical failures.
